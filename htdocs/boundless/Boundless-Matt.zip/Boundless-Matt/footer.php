<footer>
    <div class="left">
        contact us
        <form action="">
            <input type="text" placeholder="name">
            <label for=""></label>

            <input type="text" placeholder="email">
            <label for=""></label>

            <input type="text" placeholder="phone">
            <label for=""></label>

            <textarea name="" id="" placeholder="message"></textarea>
        </form>
    </div>

    <div class="right">
        <ul class="links">
            <li><a href="">Portfolio</a></li>
            <li><a href="">Show</a></li>
            <li><a href="">Press</a></li>
        </ul>

        <ul class="social">
            <li><a href="">Facebook</a></li>
            <li><a href="">Twitter</a></li>
            <li><a href="">Instagram</a></li>
            <li><a href="">Snapchat</a></li>
        </ul>

        <p class="copyright">&copy; 2017 Boundless, MCTC Graduate Design Show</p>
    </div>

</footer>

</body>
</html>
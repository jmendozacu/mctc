<?php include 'header.php'; ?>
        <section class="boundless">
            boundless
        </section>

        <section class="welcome">
            <article>
                <h1>we are boundless</h1>
                <p>
                    Synth messenger bag meh, art party post-ironic woke asymmetrical unicorn organic raw denim. Tousled
                    cardigan pinterest sriracha, echo park whatever forage unicorn cronut health goth pork belly art
                    party. Mlkshk paleo woke wolf sartorial vegan. Jean shorts shoreditch hella, meggings chia umami
                    cold-pressed. XOXO tousled umami raw denim meh seitan listicle glossier, keytar chicharrones.
                    Pinterest yuccie skateboard, coloring book blue bottle pabst vexillologist jean shorts mumblecore
                    crucifix enamel pin williamsburg celiac. Ethical vinyl aesthetic, meh lo-fi deep v af drinking
                    vinegar snackwave etsy.
                </p>

                <blockquote>
                    <p>May 3 - 4<br>
                        <small>Minneapolis Community & Technical College</small>
                    </p>
                </blockquote>
            </article>
        </section>

        <section class="portfolio">

            <article>
                <p>view our portfolios</p>
            </article>

            <div class="web">
                web div
            </div>

            <div class="print">
                print div
            </div>
        </section>

        <section class="info">
            information
        </section>

        <section class="press">
            press
        </section>

<?php include 'footer.php'; ?>
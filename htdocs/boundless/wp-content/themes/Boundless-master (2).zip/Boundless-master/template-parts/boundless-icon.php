<svg id="boundlessIcon" class="" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" viewBox="0 0 217 217">
    <defs>
        <linearGradient id="New_Gradient_Swatch_3" data-name="New Gradient Swatch 3" x1="489.697" y1="512.018" x2="573.604" y2="595.925" gradientTransform="matrix(0, -1, -1, 0, 674.434, 674.434)" gradientUnits="userSpaceOnUse">
            <stop offset="0" stop-color="#f15e78"/>
            <stop offset="1" stop-color="#c65a79"/>
        </linearGradient>
        <linearGradient id="linear-gradient" x1="-2901.758" y1="-2765.528" x2="-2982.685" y2="-2846.455" gradientTransform="matrix(1, 0, 0, -1, 3013.289, -2683.98)" gradientUnits="userSpaceOnUse">
            <stop offset="0.251" stop-color="#f8ab67"/>
            <stop offset="0.375" stop-color="#fbbc67"/>
            <stop offset="0.552" stop-color="#fdcc67"/>
            <stop offset="0.748" stop-color="#ffd667"/>
            <stop offset="1" stop-color="#ffd967"/>
        </linearGradient>
        <linearGradient id="linear-gradient-2" x1="652.508" y1="627.633" x2="567.437" y2="542.562" gradientTransform="matrix(0, -1, -1, 0, 674.434, 674.434)" gradientUnits="userSpaceOnUse">
            <stop offset="0" stop-color="#7871af"/>
            <stop offset="0.456" stop-color="#7a6bab"/>
            <stop offset="0.822" stop-color="#7d62a5"/>
        </linearGradient>
        <linearGradient id="linear-gradient-3" x1="538.976" y1="569.435" x2="603.935" y2="504.477" gradientTransform="matrix(0, -1, -1, 0, 674.434, 674.434)" gradientUnits="userSpaceOnUse">
            <stop offset="0" stop-color="#7fadb1"/>
            <stop offset="0.017" stop-color="#7bafb2"/>
            <stop offset="0.123" stop-color="#6bb8b9"/>
            <stop offset="0.254" stop-color="#5fbfbe"/>
            <stop offset="0.437" stop-color="#58c3c0"/>
            <stop offset="0.931" stop-color="#56c4c1"/>
        </linearGradient>
        <linearGradient id="linear-gradient-4" x1="126.131" y1="249.769" x2="126.131" y2="156.696" gradientTransform="matrix(1, 0, 0, 1, 0, 0)" xlink:href="#linear-gradient"/>
        <linearGradient id="New_Gradient_Swatch_3-2" x1="135.112" y1="65.854" x2="206.294" y2="137.036" gradientTransform="matrix(1, 0, 0, 1, 0, 0)" xlink:href="#New_Gradient_Swatch_3"/>
        <linearGradient id="linear-gradient-5" x1="139.537" y1="9.323" x2="68.118" y2="80.742" gradientUnits="userSpaceOnUse">
            <stop offset="0" stop-color="#7fadb1"/>
            <stop offset="0.316" stop-color="#6ab9b9"/>
            <stop offset="0.656" stop-color="#5bc1bf"/>
            <stop offset="0.931" stop-color="#56c4c1"/>
        </linearGradient>
        <linearGradient id="linear-gradient-6" x1="76.698" y1="143.347" x2="15.781" y2="82.431" gradientTransform="matrix(1, 0, 0, 1, 0, 0)" xlink:href="#linear-gradient-2"/>
        <linearGradient id="linear-gradient-7" x1="84.375" y1="13.313" x2="132.625" y2="13.313" gradientTransform="matrix(1, 0, 0, 1, 0, 0)" xlink:href="#linear-gradient-2"/>
        <linearGradient id="linear-gradient-8" x1="203.375" y1="83.063" x2="203.375" y2="131.312" gradientTransform="matrix(1, 0, 0, 1, 0, 0)" xlink:href="#linear-gradient-3"/>
        <linearGradient id="linear-gradient-9" x1="133.875" y1="202.188" x2="85.625" y2="202.188" gradientUnits="userSpaceOnUse">
            <stop offset="0" stop-color="#f15e78"/>
            <stop offset="0.805" stop-color="#e75e7a"/>
            <stop offset="1" stop-color="#e45e7a"/>
        </linearGradient>
    </defs>
    <title>boundless-compound</title>
    <g id="square" class="" data-name="Layer 1">
        <g>
            <polyline points="108.825 74.538 133.667 51.046 215.887 131.309 133.659 214.732 85.511 214.732 165.657 132.325" style="fill: url(#New_Gradient_Swatch_3)"/>
            <polyline points="141.766 107.994 166.498 131.684 85.286 214.533 2.011 132.389 2.187 84.154 85.483 164.963" style="fill: url(#linear-gradient)"/>
            <polyline points="109.246 140.861 85.844 165.217 2.187 84.154 84.412 0.931 132.647 0.93 51.838 83.938" style="fill: url(#linear-gradient-2)"/>
            <polyline points="75.957 107.908 51.6 84.507 132.788 0.93 215.887 83.074 215.887 131.309 133.743 51.076" style="fill: url(#linear-gradient-3)"/>
            <polyline points="85.473 214.732 85.473 184.53 152.067 117.849 166.788 131.781" style="fill: url(#linear-gradient-4)"/>
            <polyline points="215.887 131.309 185.686 131.309 119.397 65.46 133.68 51.177" style="fill: url(#New_Gradient_Swatch_3-2)"/>
            <polyline points="132.788 0.93 132.788 31.132 65.834 98.168 51.376 84.324" style="fill: url(#linear-gradient-5)"/>
            <polyline points="2.187 84.154 32.652 84.154 99.863 151.195 86.019 165.566" style="fill: url(#linear-gradient-6)"/>
        </g>
    </g>
    <g id="arrows" class="" data-name="Layer 2">
        <path id="arrow-1" d="M84.375.875h48.25L108.375,25.75S84.375,1.25,84.375.875Z" style="fill: url(#linear-gradient-7)"/>
        <path id="arrow-2" d="M215.813,83.063v48.25l-24.875-24.25S215.438,83.063,215.813,83.063Z" style="fill: url(#linear-gradient-8)"/>
        <path id="arrow-3" d="M133.875,214.625H85.625l24.25-24.875S133.875,214.25,133.875,214.625Z" style="fill: url(#linear-gradient-9)"/>
        <path id="arrow-4" d="M2.313,132.563V84.313l24.875,24.25S2.688,132.563,2.313,132.563Z" style="fill: #ffd967"/>
    </g>
</svg>



<!---//////////////////////////////////////////////

                    project 1 

/////////////////////////////////////////////////-->


<div id="projects" class="project-background">


<section id="project-1" class="project"> 


<h2 id="project-title">project title goes here</h2>

  <div class="portfolio-item">

  <div class="project-description-container">
    
<div class="description">
  
   {{Write a short and catchy paragraph about yourself. Lorem ipsum dolor sit amet, consectetur adipisicing elit. In totam quam aliquid esse fuga quasi, reiciendis? Temporibus tempore, harum ducimus. Sunt explicabo nisi quas praesentium nulla consequuntur officiis, ea nihil.}}

   <br><br>
   {{Write a short and catchy paragraph about yourself. Lorem ipsum dolor sit amet, consectetur adipisicing elit. In totam quam aliquid esse fuga quasi, reiciendis? Temporibus tempore, harum ducimus. Sunt explicabo nisi quas praesentium nulla consequuntur officiis, ea nihil.}} {{Write a short and catchy paragraph about yourself. Lorem ipsum dolor sit amet, consectetur adipisicing elit. In totam quam aliquid esse fuga quasi, reiciendis?
    
  <div class="next">
      <a data-scroll href="#project-2"><img  alt="arrow down" src="images/B-Assets-Final/arrow.svg" /></a>
  </div> 

</div>   <!-- end description -->

 </div>  <!-- end project description container -->


  <div class="project-image-container">

<img src="images/mock-project-2.jpg" alt="mock project">

</div>  <!-- end project image container -->

 </div>  <!-- end portfolio item -->
</section>
</div>  <!-- end project background -->




<!---//////////////////////////////////////////////

                    project 2 

/////////////////////////////////////////////////-->


<div class="project-background">


<section id="project-2" class="project"> 

<h2 id="project-title">project title goes here</h2>

  <div class="portfolio-item">

  <div class="project-description-container">
    
<div class="description">
  
   {{Write a short and catchy paragraph about yourself. Lorem ipsum dolor sit amet, consectetur adipisicing elit. In totam quam aliquid esse fuga quasi, reiciendis? Temporibus tempore, harum ducimus. Sunt explicabo nisi quas praesentium nulla consequuntur officiis, ea nihil.}}

   <br><br>
   {{Write a short and catchy paragraph about yourself. Lorem ipsum dolor sit amet, consectetur adipisicing elit. In totam quam aliquid esse fuga quasi, reiciendis? Temporibus tempore, harum ducimus. Sunt explicabo nisi quas praesentium nulla consequuntur officiis, ea nihil.}} {{Write a short and catchy paragraph about yourself. Lorem ipsum dolor sit amet, consectetur adipisicing elit. In totam quam aliquid esse fuga quasi, reiciendis?

  <div class="next">
      <a data-scroll href="#project-3"><img alt="arrow down" src="images/B-Assets-Final/arrow.svg" /></a>
  </div> 
</div>   <!-- end description -->

 </div>  <!-- end project description container -->


  <div class="project-image-container">

<img src="images/mock-project.jpg" alt="mock project">


</div>  <!-- end project image container -->

 </div>  <!-- end portfolio item -->
</section>
</div>  <!-- end project background -->




<!---//////////////////////////////////////////////

                    project 3 

/////////////////////////////////////////////////-->


<div class="project-background">


<section id="project-3" class="project"> 



<h2 id="project-title">project title goes here</h2>

  <div class="portfolio-item">

  <div class="project-description-container">
    
<div class="description">
  
   {{Write a short and catchy paragraph about yourself. Lorem ipsum dolor sit amet, consectetur adipisicing elit. In totam quam aliquid esse fuga quasi, reiciendis? Temporibus tempore, harum ducimus. Sunt explicabo nisi quas praesentium nulla consequuntur officiis, ea nihil.}}

   <br><br>
   {{Write a short and catchy paragraph about yourself. Lorem ipsum dolor sit amet, consectetur adipisicing elit. In totam quam aliquid esse fuga quasi, reiciendis? Temporibus tempore, harum ducimus. Sunt explicabo nisi quas praesentium nulla consequuntur officiis, ea nihil.}} {{Write a short and catchy paragraph about yourself. Lorem ipsum dolor sit amet, consectetur adipisicing elit. In totam quam aliquid esse fuga quasi, reiciendis?

     <div class="next">
      <a data-scroll href="#project-4"><img alt="arrow down" src="images/B-Assets-Final/arrow.svg" /></a>
  </div>   
</div>   <!-- end description -->

 </div>  <!-- end project description container -->


  <div class="project-image-container">

<img src="images/mock-project-2.jpg" alt="mock project">

</div>  <!-- end project image container -->

 </div>  <!-- end portfolio item -->
</section>
</div>  <!-- end project background -->



<!---//////////////////////////////////////////////

                    project 4 

/////////////////////////////////////////////////-->



<div class="project-background">

<section id="project-4" class="project"> 

<h2 id="project-title">project title goes here</h2>

  <div class="portfolio-item">

  <div class="project-description-container">
    
<div class="description">
  
   {{Write a short and catchy paragraph about yourself. Lorem ipsum dolor sit amet, consectetur adipisicing elit. In totam quam aliquid esse fuga quasi, reiciendis? Temporibus tempore, harum ducimus. Sunt explicabo nisi quas praesentium nulla consequuntur officiis, ea nihil.}}

   

  <div class="next">
      <a data-scroll href="#project-5"><img  alt="arrow down" src="images/B-Assets-Final/arrow.svg" /></a>
  </div> 
</div>   <!-- end description -->

 </div>  <!-- end project description container -->


  <div class="project-image-container">

<img src="images/mock-project.jpg" alt="mock project">


</div>  <!-- end project image container -->

 </div>  <!-- end portfolio item -->
</section>
</div>  <!-- end project background -->



<!---//////////////////////////////////////////////

                    project 5 

/////////////////////////////////////////////////-->


<div class="project-background">

<section id="project-5" class="project"> 



<h2 id="project-title">project title goes here</h2>

  <div class="portfolio-item">

  <div class="project-description-container">
    
<div class="description">
  
   {{Write a short and catchy paragraph about yourself. Lorem ipsum dolor sit amet, consectetur adipisicing elit. In totam quam aliquid esse fuga quasi, reiciendis? Temporibus tempore, harum ducimus. Sunt explicabo nisi quas praesentium nulla consequuntur officiis, ea nihil.}}

   <br><br>
   {{Write a short and catchy paragraph about yourself. Lorem ipsum dolor sit amet, consectetur adipisicing elit. In totam quam aliquid esse fuga quasi, reiciendis? Temporibus tempore, harum ducimus. Sunt explicabo nisi quas praesentium nulla consequuntur officiis, ea nihil.}} {{Write a short and catchy paragraph about yourself. Lorem ipsum dolor sit amet, consectetur adipisicing elit. In totam quam aliquid esse fuga quasi, reiciendis?

       <div class="next">
      <a data-scroll href="#"><img alt="arrow down" src="images/B-Assets-Final/arrow.svg" /></a>
  </div> 
</div>   <!-- end description -->

 </div>  <!-- end project description container -->


  <div class="project-image-container">

<img src="images/mock-project-2.jpg" alt="mock project">

</div>  <!-- end project image container -->

 </div>  <!-- end portfolio item -->
</section>
</div>  <!-- end project background -->




